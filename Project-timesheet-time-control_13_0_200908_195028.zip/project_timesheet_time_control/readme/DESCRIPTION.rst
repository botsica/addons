Allow to track the exact moment when a timesheet line is started (not only
the day, but also the minute and second) and let users start and stop timers
easily.
