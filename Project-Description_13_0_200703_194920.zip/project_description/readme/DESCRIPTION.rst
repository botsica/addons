This module extends the functionality of projects to support setting a
description for each project and allow you to search by that description.
