Open ERP System :- odoo13 Community


Installation 
============

Install the Application => Apps -> Customer Search Filter (Technical Name: customer_search_filter)


Version
========

	Odoo v13


Module Configuration Guideline
================================

	There are no Configuration required after the installation of this module.


Customer Search Filter Module Functionality
================================================

This module helps in finding a customer with respect to its mobile number, phone number, city, 
email and its job position.

A customer can be selected from the the list of its matching mobile number, phone number, city, email and its job position.

This functionality will be applied when we want to search customer in any object.
