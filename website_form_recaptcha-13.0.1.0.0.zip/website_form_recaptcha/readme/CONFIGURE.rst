First of all you must obtain
a ReCaptcha key from `Google <http://www.google.com/recaptcha/admin>`_

**Multi website setup**

* Go to website settings
* Select the website you want to add / edit the recaptcha key
* Set site key and secret key
