To use this module, you need to:

* Already have a form-enabled model (refer to `website_form` docs)
* Set `website_form_recaptcha` to `True` on that model (similar to enabling forms)
* Add an element with the `o_website_form_recaptcha` class anywhere in the form

Look at `website_crm_recaptcha` module for example implementation.
