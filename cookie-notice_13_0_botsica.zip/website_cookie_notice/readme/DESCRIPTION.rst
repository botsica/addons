This module adds the cookie notice, according to the `european cookie law
<https://wikis.ec.europa.eu/display/WEBGUIDE/04.+Cookies>`_,
to your website.
