* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Nicola Malcontenti <nicola.malcontenti@agilebg.com>
* Nicolas JEUDY <https://github.com/njeudy>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Rafael Blasco
  * Jairo Llopis
  * Ernesto Tejeda
  * Alexandre Díaz
* Bjorn Billen <bjorn.billen@dynapps.be>
