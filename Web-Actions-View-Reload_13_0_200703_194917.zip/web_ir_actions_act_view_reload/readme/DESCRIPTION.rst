This module provides a way to trigger reload of the current window on ActionManager
