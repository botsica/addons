In order to set up the budget items go to
*Invoicing / Accounting / Miscellaneous / Account Move Budgets*.
