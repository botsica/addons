Website editor can change easily any text of these pages using website builder.

If you install this module after 'website_sale', it will be merge the content
of 'website_sale.terms' into a new page.

This module hard-redirect '/shop/terms' to '/legal'.


Disclaimer
~~~~~~~~~~

These legal pages are templates.

**You must edit the templates and adapt them to your particular case**

The provided agreements are for **informational purposes only** and do not
constitute legal advice.

Authors, contributors and maintainer are not law firms and are not providing legal advice.
All information (including agreements, forms and documents) available in this
addon are **provided without any warranty**, express or implied, including as to
their legal effect and completeness. The information **should be used as a
guide** and modified to meet your own individual needs and the laws of your
state. Your use of any information or forms is at your own risk.

Authors, contributors, maintainer and any of its employees, contractors, or
attorneys who participated in development of this addon **expressly disclaim any
warranty**: they are not creating or entering into any Attorney-Client
relationship by providing information to you.
