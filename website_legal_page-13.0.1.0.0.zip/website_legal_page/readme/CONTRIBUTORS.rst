* Antonio Espinosa <antonioea@antiun.com>
* Igor Pastor <igorpg@antiun.com>
* Dave Lasley <dave@laslabs.com>
* Nicola Malcontenti <nicola.malcontenti@agilebg.com>
* Nicolas JEUDY <https://github.com/njeudy>
* Lorenzo Battistini <https://github.com/eLBati>
* Eduardo Magdalena <emagdalena@c2i.es> (C2i Change 2 improve http://www.c2i.es)

* `Tecnativa <https://www.tecnativa.com>`_:

  * Rafael Blasco
  * Jairo Llopis
  * Alexandre Diaz
