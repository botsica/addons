This module enables the user to define dependencies (other tasks) of a task.
